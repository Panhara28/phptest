<?php
    for ($i=0;$i < count($array[3000]);$i++){
      echo '<option value="'.$array[3000][$i].'">'.$array[3000][$i].'</option>';
    }
    for ($i=0;$i < count($array[4000]);$i++){
      echo '<option value="'.$array[4000][$i].'">'.$array[4000][$i].'</option>';
    }
    for ($i=0;$i < count($array[2000]);$i++){
      echo '<option value="'.$array[2000][$i].'">'.$array[2000][$i].'</option>';
    }
    for ($i=0;$i < count($array[1000]);$i++){
      echo '<option value="'.$array[1000][$i].'">'.$array[1000][$i].'</option>';
    }
?>
